CameraImages contains the images from View1 to View4
the idx refers to the camera idx. So View1 represents image from camera 1, View2 from cam2 and so on.

3 point clouds from each pair of cameras are given
Format for point cloud is cam_camera1idx_camera2idx.ply
Ex : cam_1_2.ply is the point cloud formed by camera 1 and 2 images( i.e. view1 and view2)

CalibrationParameters.txt contain the projection matrices for each camera